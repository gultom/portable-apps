$(document).ready(function () {
    // Fetch menu data from JSON file on the server
    $.getJSON("http://localhost/vp-services/menu.json", function (data) {
        // Populate the sidebar menu
        var $menuList = $("#menu-list");
        $.each(data, function (key, value) {
            var $menuItem = $("<a>")
                .addClass("list-group-item list-group-item-action shadow p-3")
                .attr("title", "Double-click to open " + value.alias)
                .html(`<img src="${value.icon}" alt="${key}" class="mr-2 img-fluid img-thumbnail rounded-circle" style="width: 100% \\9; max-width: 48px; max-height: 48px" /> ${key}`)
                .css("margin", "5px") // Add margin
                .on("click", function () {
                    showDescription(value.alias, value.description, value.url);
                })
                .on("dblclick", function () {
                    window.open(value.url, "_blank");
                });
            $menuList.append($menuItem);
        });
    });

    let currentlyTyping = false;

    // Function to display description in the main content area
    async function showDescription(alias, description, url) {
        if (currentlyTyping) {
            console.log('currently typing, request rejected!');
            return;
        }
        currentlyTyping = true;
        // $('#description-title').html('');
        // $('#description-content').html('');
        // await typeWriter('description-title', alias);
        // await typeWriter('description-content', description);

        $('#description-title').html(alias);
        $('#description-content').html(description);

        // The second typeWriter is called after the first one completes
        $('#description-content').append(`<p><a class='btn btn-warning float-end' style='min-width: 100px' href='${url}' target='_blank'>Go ></a></p>`);
        currentlyTyping = false;

    }

    function typeWriter(component, myText) {
        return new Promise(resolve => {
            $(`#${component}`).html('');
            var i = 0;
            var strLength = myText.length;
            var timeoutId; // Variable to store the timeout ID

            function type() {
                if (i < strLength) {
                    document.getElementById(component).innerHTML += myText.charAt(i);
                    i++;
                    timeoutId = setTimeout(type, 0.1);
                } else {
                    // Resolve the promise when typing is complete
                    resolve();
                }
            }

            // Call type function to start typing
            type();

            // If typeWriter is called again before the typing animation is complete, clear the timeout
            return () => clearTimeout(timeoutId);
        });
    }

});