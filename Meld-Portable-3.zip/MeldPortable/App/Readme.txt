This directory contains files used by the portable app.
They should generally not be accessed directly by users.

User data or settings should not be stored within the App
directory or its sub-directories.  Any data stored here
will likely be deleted on upgrades.